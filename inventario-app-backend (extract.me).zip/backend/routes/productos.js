const express = require('express');
const router = express.Router();

let productos = [];

/**
 * @swagger
 * /api/productos:
 *   get:
 *     summary: Obtener todos los productos
 *     responses:
 *       200:
 *         description: Lista de productos
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 */
router.get('/', (req, res) => {
  res.json(productos);
});

/**
 * @swagger
 * /api/productos:
 *   post:
 *     summary: Crear un nuevo producto
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               nombre:
 *                 type: string
 *               cantidad:
 *                 type: integer
 *     responses:
 *       201:
 *         description: Producto creado
 */
router.post('/', (req, res) => {
  const { nombre, cantidad } = req.body;
  const nuevoProducto = { id: Date.now(), nombre, cantidad };
  productos.push(nuevoProducto);
  res.status(201).json(nuevoProducto);
});

module.exports = router;
const swaggerJSDoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'API Inventarios',
      version: '1.0.0',
      description: 'Documentación de la API del sistema de gestión de inventarios',
    },
    servers: [
      {
        url: 'http://localhost:3001',
        description: 'Servidor local',
      },
    ],
  },
  apis: ['./routes/*.js'],
};

module.exports = swaggerJSDoc(options);
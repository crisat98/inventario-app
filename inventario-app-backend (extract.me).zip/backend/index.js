const express = require('express');
const cors = require('cors');
const productosRouter = require('./routes/productos');
const swaggerUI = require('swagger-ui-express');
const swaggerSpec = require('./swagger/swaggerConfig');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/productos', productosRouter);
app.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpec));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
  console.log(`Documentación Swagger en http://localhost:${PORT}/api-docs`);
});